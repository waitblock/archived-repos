![](https://waitblock.github.io/Dodge-It/logo.png)

# Dodge It!

A clone of the Atari 2600 game Miss It!.

Download the game [here](https://waitblock.github.io/Dodge-It/).
