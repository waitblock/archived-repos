import os
import random

print("Conceptual: The Terminal Program That Helps You Study")
print("v0.02")

with open("menu.txt") as file:
    MENU_TEXT = file.read()


def main():
    while True:
        print(MENU_TEXT)
        choice = input("Enter an option: ")
        if choice == "1":
            new_set = {}
            set_name = input("Name this set: ")
            if "\\" in set_name or "/" in set_name:
                print("Your set name cannot contain a back or foward slash")
                continue
            if os.path.isfile(os.path.join(os.getcwd(), f"{set_name}.concep")) is True:
                print("Warning! A set already exists with this name. Recreating a new set with this name will overwrite it.")
                cont = input("Do you wish to continue? (y/n) ").lower()
                if cont == "y":
                    pass
                if cont == "n":
                    continue
            print("Type /exit-create to end the set.")
            while True:
                new_term = input("Enter a new term: ")
                if new_term.lower() == "/exit-create":
                    break
                new_def = input("Enter a the definition for the new term: ")
                if new_def.lower() == "/exit-create":
                    break
                new_set[new_term] = new_def
            new_set_file = open(f"{set_name}.concep", "w")
            for term in new_set.keys():
                # print(f"{term} {new_set[term]}")
                new_set_file.write(f"{term} {new_set[term]}\n")
            new_set_file.close()
        if choice == "2":
            set_name = input("Enter the name of the set: ")
            if os.path.isfile(os.path.join(os.getcwd(), f"{set_name}.concep")) is False:
                print("A set does not exist with this name.")
                continue
            if "\\" in set_name or "/" in set_name:
                print("The set name cannot contain a back or foward slash")
                continue
            with open(f"{set_name}.concep") as file:
                raw_set = file.read().split("\n")
            raw_set = raw_set[0:len(raw_set)-1]
            terms = []
            defs = []
            for i in range(len(raw_set)):
                terms.append(raw_set[i].split(" ")[0])
                defs.append(raw_set[i].split(" ")[1])
            for i in range(len(terms)):
                term = random.choice(terms)
                defi = defs[terms.index(term)]
                terms.remove(term)
                defs.remove(defi)
                attempt = input(f"What is the definition of the {term}? ")
                if attempt.lower() == defi.lower():
                    print("Correct!")
                else:
                    print(f"Incorrect! The definition was {defi.lower()}.")

        if choice == "3":
            exit()


if __name__ == "__main__":
    main()
