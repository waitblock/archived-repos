# Chess Clock

A simple chess clock made in Processing.

## Contributing

Have an idea for a new feature? / Find a problem in the code? [Create an issue and post it there](https://github.com/waitblock/chess-clock/issues)

Want to contribute code? [Create a pull request](https://github.com/waitblock/chess-clock/pulls)

## Release Numbering Method

{Year of Release}.{Month of Release}.{Day of Release}

## Running the binary on MacOS (unverified developer warning)

https://support.apple.com/guide/mac-help/open-a-mac-app-from-an-unidentified-developer-mh40616/mac
