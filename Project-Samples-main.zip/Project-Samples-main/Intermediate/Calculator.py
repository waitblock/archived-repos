import math

while True:
    try:
        exp = input("Enter an expression or type 'help' or 'quit': ").split(" ")
        if len(exp) == 1:
            if exp[0] == "help":
                print("Operations List:")
                print("<number> + <number>")
                print("<number> - <number>")
                print("<number> * <number>")
                print("<number> / <number>")
                print("<number> ^ <number>")
                print("sqrt <number>")
                print("round <number>")
                print("ceil <number>")
                print("floor <number>")
                print("cos <number>")
                print("sin <number>")
                print("tan <number>")
            if exp[0] == "quit":
                break

        elif len(exp) == 2:
            if exp[0] == "sqrt":
                print(math.sqrt(float(exp[1])))
            if exp[0] == "round":
                print(round(float(exp[1])))
            if exp[0] == "ceil":
                print(math.ceil(float(exp[1])))
            if exp[0] == "floor":
                print(math.floor(float(exp[1])))
            if exp[0] == "cos":
                print(math.cos(float(exp[1])))
            if exp[0] == "sin":
                print(math.sin(float(exp[1])))
            if exp[0] == "tan":
                print(math.tan(float(exp[1])))


        elif len(exp) == 3:
            if exp[1] == "+":
                print(float(exp[0])+float(exp[2]))
            if exp[1] == "-":
                print(float(exp[0])-float(exp[2]))
            if exp[1] == "*":
                print(float(exp[0])*float(exp[2]))
            if exp[1] == "/":
                print(float(exp[0])/float(exp[2]))
            if exp[1] == "^":
                print(float(exp[0])**float(exp[2]))

    except:
        pass
