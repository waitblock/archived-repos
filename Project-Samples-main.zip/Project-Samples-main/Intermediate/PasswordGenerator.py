import random

only_letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
                'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
                'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a',
                'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
                'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                't', 'u', 'v', 'w', 'x', 'y', 'z']

numbers = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
           'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
           'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a',
           'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
           'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
           't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1',
           '2', '3', '4', '5', '6', '7', '8', '9']

symbols = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
           'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
           'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a',
           'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
           'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
           't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1',
           '2', '3', '4', '5', '6', '7', '8', '9', '!',
           '@', '#', '$', '%', '^', '&', '*', '(', ')',
           '~', '`', '"', '\'', '_', '-', '+', '=', '{',
           '}', '[', ']', '|', ';', ':', ',', '.', '?',
           '/']

print("Password Generator")
print("Type 'exit' to exit.")

while True:
    print("1. Letters Only")
    print("2. Letters and Numbers Only")
    print("3. Letters, Numbers, & Symbols")
    choice = input("Enter your choice: ")

    if choice == "exit":
        break

    length = int(input("Enter the length of the password: "))
    password = ""
    if choice == "1":
        for i in range(length):
            password += random.choice(only_letters)

    if choice == "2":
        for i in range(length):
            password += random.choice(numbers)

    if choice == "3":
        for i in range(length):
            password += random.choice(symbols)

    print(password)
