names = []
phones = []
emails = []
addrs = []

while True:
    print("1. Add contact")
    print("2. Remove contact")
    print("3. Get contact info")
    print("4. View contacts")
    print("5. Delete all contacts")
    print("6. Exit")
    option = input()
    if option == "1":
        name = input("Enter name: ")
        phone = input("Enter phone number: ")
        email = input("Enter email: ")
        addr = input("Enter address: ")
        names.append(name)
        phones.append(phone)
        emails.append(email)
        addrs.append(addr)

    if option == "2":
        in_contacts = False
        to_remove = input("Enter name of contact to remove: ")
        for i in range(len(names)):
            if names[i] == to_remove:
                rm_index = i
                in_contacts = True
                break
        if in_contacts == True:
            names.pop(rm_index)
            phones.pop(rm_index)
            emails.pop(rm_index)
            addrs.pop(rm_index)
        elif in_contacts == False:
            print("That contact is not in your list of contacts.")

    if option == "3":
        in_contacts = False
        contact_name = input("Enter the name of the contact: ")
        for i in range(len(names)):
            if names[i] == contact_name:
                index = i
                in_contacts = True
                break
        if in_contacts == True:
            print("Name: "+names[index])
            print("Phone: "+phones[index])
            print("Email: "+emails[index])
            print("Address: "+addrs[index])
        elif in_contacts == False:
            print("That contact is not in your list of contacts.")

    if option == "4":
        for i in range(len(names)):
            print("Name: "+names[i])
            print("Phone: "+phones[i])
            print("Email: "+emails[i])
            print("Address: "+addrs[i])
            print("\n")

    if option == "5":
        del names[:]
        del phones[:]
        del emails[:]
        del addrs[:]

    if option == "6":
        break
