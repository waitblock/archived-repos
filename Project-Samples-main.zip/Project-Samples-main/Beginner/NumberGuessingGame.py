import random

number = random.randint(1, 100)

print("I am thinking of a number between 1 and 100. Can you guess it?")

while True:
    answer = int(input("Enter your guess: "))
    if answer > number:
        print("Too high!")
    elif answer < number:
        print("Too low!")
    elif answer == number:
        print("You guessed the number!")
        break
