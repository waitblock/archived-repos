amount = int(input("Enter the amount of terms: "))

a = 1
b = 1

for i in range(amount):
    print(a)
    sum = a + b
    a = b
    b = sum
