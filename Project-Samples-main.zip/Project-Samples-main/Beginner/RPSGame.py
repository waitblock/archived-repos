import random

plays = ["r", "p", "s"]

while True:
    play = random.choice(plays)
    player = input("Enter '(R)ock', '(P)aper', or '(S)cissors': ").lower()
    if player == "r" or player == "rock":
        if play == "r":
            print("You played rock, I played rock, so we tied!")
        elif play == "p":
            print("You played rock, I played paper, so I win!")
        elif play == "s":
            print("You played rock, I played scissors, so you win!")
    elif player == "p" or player == "paper":
        if play == "r":
            print("You played paper, I played rock, so you win!")
        elif play == "p":
            print("You played paper, I played paper, so we tied!")
        elif play == "s":
            print("You played paper, I played scissors, so I win!")
    elif player == "s" or player == "scissors":
        if play == "r":
            print("You played scissors, I played rock, so I win!")
        if played == "p":
            print("You played scissors, I played paper, so you win!")
        if played == "s":
            print("You played scissors, I played scissors, so we tied!")