import random

for i in range(10):
    print("You rolled a "+str(random.randint(1,6))+"!")
