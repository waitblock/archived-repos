This is still a work in progress

To test the program, download the files and run the program using ``java Athenaeum.java``

The system password is "password"
