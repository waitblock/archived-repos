import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;

public class Athenaeum {

	public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
		//initialization stuff
		Scanner sc = new Scanner(System.in);
		System.out.println("Athenaeum v1.0");
		System.out.println("(c) 2021 Ethan\n");

		//password checking
		while(true) {
			System.out.println("Enter system password: ");
			String password_attempt = sc.nextLine();
			if(checkPassword(password_attempt)) {
				System.out.println("Correct password");
				break;
			}
			else {
				System.out.println("Incorrect password, try again\n");
			}
		}

		//main loop for program
		while(true) {
			printMenu();
			String option = sc.nextLine();

			if(option.equals("4")){
				addBook();
			}

			if(option.equals("6")){
				changePassword();
			}

			if (option.equals("7")) {
				System.exit(0);
			}
		}
	}

	//function to add a book to the system
	private static void addBook() throws IOException{
		Scanner sc = new Scanner(System.in);
		FileWriter writer = new FileWriter("books.txt", true);

		System.out.println("Enter book barcode/ID number:");
		String barcode = sc.nextLine();
		System.out.println("Enter book title:");
		String title = sc.nextLine();
		System.out.println("Enter book author:");
		String author = sc.nextLine();

		ArrayList<String> books = parseBookFile();

		if(doesBookExist(books, barcode)){
			System.out.println("Book already exists");
		}
		else{
			writer.write(barcode + " " + title + " " + author + " true\n");
		}
		writer.close();
	}

	//function to check password input
	private static boolean checkPassword(String pwd_attempt) throws NoSuchAlgorithmException, IOException {
		MessageDigest digest;
		digest = MessageDigest.getInstance("SHA-256");
		byte[] encodedHash = digest.digest(pwd_attempt.getBytes(StandardCharsets.UTF_8));
		String pwd_attempt_hash = bytesToHex(encodedHash);

		String working_directory = System.getProperty("user.dir").toString();
		File password_file = new File(Paths.get(working_directory, "password_hash.txt").toString());

		BufferedReader br = new BufferedReader(new FileReader(password_file));
		String pwd_hash = br.readLine();

		if(pwd_attempt_hash.equals(pwd_hash)) {
			return true;
		}
		return false;
	}

	//function to change password
	private static void changePassword() throws NoSuchAlgorithmException, IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter system password: ");
		String password_attempt = sc.nextLine();

		if(checkPassword(password_attempt)) {
			System.out.println("Correct password\n");
			System.out.println("Enter a new password:");
			String new_password = sc.nextLine();

			MessageDigest digest;
			digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedHash = digest.digest(new_password.getBytes(StandardCharsets.UTF_8));
			String new_password_hash = bytesToHex(encodedHash);

			FileWriter filewriter = new FileWriter("password_hash.txt", false);
			PrintWriter writer = new PrintWriter(filewriter, false);
			writer.flush();
			writer.println(new_password_hash);
			writer.close();
			filewriter.close();
		}
		else {
			System.out.println("Incorrect password, try again\n");
		}
	}

	//function to print menu
	private static void printMenu() {
		System.out.println("\n=============");
		System.out.println("Menu");
		System.out.println("=============");
		System.out.println("(1) Check-out book");
		System.out.println("(2) Check-in book");
		System.out.println("(3) Check book status");
		System.out.println("(4) Add book to system");
		System.out.println("(5) Remove book from system");
		System.out.println("(6) Change system password");
		System.out.println("(7) Quit & shutdown system");
	}

	//function to parse book file data
	private static ArrayList<String> parseBookFile() throws IOException{
		String working_directory = System.getProperty("user.dir").toString();
		File book_file = new File(Paths.get(working_directory, "books.txt").toString());
		BufferedReader br = new BufferedReader(new FileReader(book_file));
		ArrayList<String> books = new ArrayList<String>();
		String book = br.readLine();
		books.add(book);

		while(book != null){
			book = br.readLine();
			books.add(book);
		}

		br.close();
		books.remove(books.size()-1);
		return books;
	}

	//function to check if a book with a barcode already exists in the system
	private static boolean doesBookExist(ArrayList<String> al, String value) {
		for(String book : al){
			String[] book_details = book.split(" ");
			if(value.equals(book_details[0])){
				return true;
			}
		}
		return false;
	}

	//function to convert bytes array to hex string
	private static String bytesToHex(byte[] hash) {
	    StringBuilder hexString = new StringBuilder(2 * hash.length);
	    for (int i = 0; i < hash.length; i++) {
	        String hex = Integer.toHexString(0xff & hash[i]);
	        if(hex.length() == 1) {
	            hexString.append('0');
	        }
	        hexString.append(hex);
	    }
	    return hexString.toString();
	}

}
