# Red Kart I - PyJam 2021 Project

*(Last Updated June 24, 2021 - Final Version)*

<img src=https://github.com/waitblock/Red-Kart-I/blob/main/cover.png height="450" width="auto"></img>

## Description
A karting game made using Unity and compiled using Unity WebGL.

## Info
- Language: C#
- Why You Cannot Win: There is a given amount of time in which you have to complete the game. However, there is not enough time given, so it is impossible to complete the game.
- Libraries/Frameworks Used: Unity PostProcessing, Unity ProBuilder, Unity WebGL Compiler (Default Library), NVIDIA PhysX (Default Library)

## Minimum Requirements
- CPU: Any CPU with a clock speed of at least 1.1GHz
- RAM: Any RAM that has a memory capacity of at least 2GB
- GPU: Any GPU with at least DirectX 9 and at least 512MB of video memory
