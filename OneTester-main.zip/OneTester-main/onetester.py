import sys
import re
import os
import traceback

try:
    from colorama import Fore
    from colorama import Style
except ModuleNotFoundError:
    print("Required dependencies missing: Install with python3 -m pip install -r requirements.txt")
    sys.exit(1)

print("OneTester 2021.11.7")
print("(c) 2021 Ethan Xu")
print()

flags = sys.argv[2:]
command_flags = []
python_file_regex = re.compile(".+[.]py")


def main():
    # Creating a variable for the folder path
    try:
        folder_path = sys.argv[1]
    except IndexError:
        print("Missing required argument: folderPath")
        sys.exit(1) # Exit with code 1 if the folder path is missing

    # Checking for unknown flags
    for flag in flags:
        if flag not in command_flags:
            print(f"Unknown flag: {flag}")
            sys.exit(1)

    # Retrieving all the file names
    try:
        files_in_path = os.listdir(folder_path)
    except FileNotFoundError:
        print("Invalid argument: folderPath")
        sys.exit(1)
    print(f"Files in path: {files_in_path}")

    # Filtering out python files
    python_file_paths = []
    python_filenames = []
    for filename in files_in_path:
        if bool(python_file_regex.match(filename)):
            python_file_paths.append(os.path.join(folder_path, filename))
            python_filenames.append(filename)
    print(f"Python filepaths: {python_file_paths}")
    print(f"Python filenames: {python_filenames}")

    print()
    print("======== Testing ========")
    results = []
    for i in range(len(python_filenames)):
        file_name = python_filenames[i]
        print(f"Testing {file_name}...")
        # Checks files for errors by compiling them
        try:
            compile(open(python_file_paths[i]).read(), file_name, "exec")
        except:
            # If the program throws an error, add a failed result
            print(f"{Fore.MAGENTA}Traceback stack:{Style.RESET_ALL}")
            traceback.print_exc()
            results.append(False)
            continue
        # If the program does not throw an error, add a passed result
        results.append(True)

    print()
    print("======== Testing Results ========")

    for result in results:
        if result:
            print(f"{Fore.BLUE}{python_filenames[i]}{Style.RESET_ALL}: {Fore.GREEN}PASS{Style.RESET_ALL}")
        elif not result:
            print(f"{Fore.BLUE}{python_filenames[i]}{Style.RESET_ALL}: {Fore.RED}FAIL{Style.RESET_ALL}")


if __name__ == "__main__":
    main()

print("Testing completed.")
