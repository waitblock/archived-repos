
var state;

/*
0 - Ready to Start
1 - Clicking
2 - Done Clicking
*/
var cps;

var clicks;

function setup() {
    initializeFields();
    createCanvas(800, 600);
}

function draw() {
    background(255);
    noStroke();
    if (state === 0) {
        textSize(60);
        fill(0);
        text("Click anywhere to begin.", 10, 60);
        text("Last test: " + cps + "CPS", 10, 140);
        if (mouseIsPressed) {
            state = 1;
            clicks = 0;
            frameCount = 0;
        }
    }
    if (state == 1) {
        textSize(300);
        fill(0);
        text(clicks, 10, 350);
        textSize(80);
        text("Time: " + int(frameCount / 60), 10, 500);
        textSize(40);
        text("Press any key to quit.", 10, 550);
        if (keyIsPressed) {
            state = 0;
        }
        if (frameCount == 600) {
            state = 2;
            cps = float(clicks) / 10.0;
        }
    }
    if (state == 2) {
        textSize(80);
        text("Finished!", 10, 90);
        textSize(40);
        text("Press any key to continue.", 10, 180);
        if (keyIsPressed) {
            state = 0;
        }
    }
}

function mouseReleased() {
    if (state == 1) {
        clicks++;
    }
}

function initializeFields() {
    state = 0;
    cps = 0;
    clicks = 0;
}
