import os
import socket
import sys
import platform
if platform.system() != 'Darwin':
    print("This program will only work on MacOS")
    exit()

def checkPing():
    hostname = input("Enter a website to check: ")
    if hostname == "exit":
        exit()
    response = os.system("ping -c 1 " + hostname)
    if response == 0:
        pingstatus = "Network Active"
    else:
        pingstatus = "Network Error"

    hostname_ip = socket.gethostbyname(hostname)
    print("\n\n")

    print(pingstatus, "on IP Address",hostname_ip)
    print()

print("Type 'exit' to quit.")
while True:
    checkPing()