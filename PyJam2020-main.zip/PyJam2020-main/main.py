#I also made a project in processing for this game jam.
#Check it out at: https://www.ktbyte.com/projects/project/415761/

from random import randint
from time import sleep

print_debug = False #set to true to print debug information

game_running = True
store_cards = []
twists = ["Draw 2",
          "Discard 1",
          "Draw 5",
          "Discard 3",
          "Tell everyone a secret",
          "Tell everyone a joke",
          "Sing a song",
          "Tell everyone a random fact"]


def initalize():
    global players
    global cards
    print("PyJam 2020 Project")
    print("Uno, but with a Twist")
    print("This is pretty much just Uno, but with no colors.")
    print("The twist is that some cards are 'With a Twist', and when you")
    print("get those cards, the program randomly generates a twist.")

    print("Press Control-C to quit.")
    players = int(input("How many players are there? "))
    cards = int(input("How many cards would you like each player to have? "))
    print("Initializing...")

def clear_screen():
    for i in range(40):
        print("\n")

def check_hand_for_card(hand, card):
    card_in_hand = False
    for i in range(len(hand)):
        if hand[i] == card:
            card_in_hand = True

    for i in range(len(hand)):
        if hand[i] == "Wild":
            card_in_hand = True

    for i in range(len(hand)):
        if hand[i] == "Add a Twist":
            card_in_hand = True

    if card_in_hand == True:
        return True
    elif card_in_hand == False:
        return False


while True:
    try:

        # initial setup
        initalize()
        starting_card = str(randint(1, 6))
        for i in range(players):
            hand_to_add = []
            for i in range(cards):
                card_to_add = str(randint(1, 8))
                if card_to_add == "7":
                    card_to_add = "Add a Twist"
                    hand_to_add.append(card_to_add)
                elif card_to_add == "8":
                    lower_wild_chance = randint(1,4)
                    if lower_wild_chance == 1:
                        card_to_add = "Wild"
                        hand_to_add.append(card_to_add)
                    else:
                        hand_to_add.append(str(randint(1,4)))
                else:
                    hand_to_add.append(card_to_add)
            store_cards.append(hand_to_add)
        if print_debug == True:
            print("\n")
            print("Debug Information:")
            print("Player Hands:", (store_cards))
            print("Number of Players:", (players))
            print("Number of Cards per Player:", (cards))
            print("\n")

        current_card = starting_card

        while True:
            for i in range(players):
                if current_card == "Wild" or current_card == "Add a Twist":
                    current_card = str(randint(1, 6))
                print("The card on top is:", current_card)
                player_turn = i + 1
                print("It's player ", (player_turn), "'s turn!", sep="")
                player_hand = store_cards[i]
                print("Current player's hand:", (player_hand))
                player_index = player_turn - 1

                while True:
                    try:

                        if check_hand_for_card(player_hand, current_card) == True:
                            card_to_play = input("Enter a card to play: ")
                            store_cards[i].remove(card_to_play)
                            if card_to_play == current_card or card_to_play == "Wild":
                                if card_to_play != "Wild":
                                    current_card = card_to_play
                                else:
                                    current_card = str(randint(1, 6))
                                sleep(0.5)
                                break
                            elif card_to_play == "Add a Twist":
                                twist_chosen = randint(0, 7)
                                print(twists[twist_chosen])
                                if twists[twist_chosen] == "Draw 2":
                                    for i in range(2):
                                        store_cards[player_index].append(str(randint(1, 6)))

                                if twists[twist_chosen] == "Discard 1":
                                    store_cards[player_index].pop(0)

                                if twists[twist_chosen] == "Draw 5":
                                    for i in range(5):
                                        store_cards[player_index].append(str(randint(1, 6)))

                                if twists[twist_chosen] == "Discard 3":
                                    for i in range(3):
                                        store_cards[player_index].pop(0)

                                continue_game = input("Press enter to continue. ")
                                break

                        elif check_hand_for_card(player_hand, current_card) == False:
                            print("There is no card in your hand which matches the top card.")
                            print("Drawing a card...")
                            store_cards[i].append(str(randint(1, 6)))
                            sleep(3)
                            break



                    except ValueError:
                        print("The card chosen is not in your hand. Pick another one.")

                    except IndexError:
                        print("Player", (player_turn), "wins!")
                        exit()


                if len(store_cards[player_index]) == 0:
                    print("Player", (player_turn), "wins!")
                    exit()

                clear_screen()




    except KeyboardInterrupt:
        break
