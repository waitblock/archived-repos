import matplotlib.pyplot as plt
import numpy as np
from utils import *

print("Reading file in array...")
with open("parsed.txt", "r") as datafile:
    parsed_data = datafile.read().split("\n")

data = []

# format for each line: [game type],[white elo rating],[black elo rating],[opening played]
print("Formatting data...")
for i in range(len(parsed_data)-1):
    type = parsed_data[i].split("%")[0]
    white_elo = int(parsed_data[i].split("%")[1])
    black_elo = int(parsed_data[i].split("%")[2])
    opening = parsed_data[i].split("%")[3]
    data.append([type, white_elo, black_elo, opening])

openings = {}

print("Scanning openings...")
for i in range(len(data)):
    opening_played = data[i][3]
    if opening_played not in openings:
        openings[opening_played] = 1
    else:
        openings[opening_played] += 1

sorted = list(invert(sort_by_value(openings)).items())
print(sorted)
pie_labels = []
pie_sizes = []

for i in range(len(sorted)):
    pie_labels.append(sorted[i][1])
    pie_sizes.append(sorted[i][0])

pie_labels = pie_labels[len(sorted)-20:len(sorted)-1]
pie_sizes = pie_sizes[len(sorted)-20:len(sorted)-1]

print(pie_labels)
print(pie_sizes)

fig1, ax1 = plt.subplots()
ax1.pie(pie_sizes, labels=pie_labels, autopct="%1.1f%%")
ax1.axis('equal')
plt.show()
