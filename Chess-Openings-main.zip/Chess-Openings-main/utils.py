def sort_by_value(dict):
    return {k: v for k, v in sorted(dict.items(), key=lambda item: item[1])}

def invert(dict):
    return {v: k for k, v in dict.items()}
