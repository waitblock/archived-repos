raw_data = []

with open("lichess_db_standard_rated_2014-01.pgn", "r") as input_file:
    # parse data into array
    print("Reading file into array...")
    raw_data = input_file.read().split("\n\n")

# remove move data
print("Extracting game data into array...")
game_data = []
for i in range(0,len(raw_data),2):
    game_data.append(raw_data[i])

# extract rating, opening, and game type (bullet, blitz, etc.)
print("Extracting useful information from game data...")
parsed_data = []
for i in range(len(game_data)-1):
    try:
        game = game_data[i].split("\n")
        parsed = []
        parsed.append(game[0].split("\"")[1]) # game type
        parsed.append(int(game[7].split("\"")[1])) # white elo rating
        parsed.append(int(game[8].split("\"")[1])) # black elo rating
        parsed.append(game[12].split("\"")[1]) # opening played
        parsed_data.append(parsed)
    except ValueError:
        continue # skip game if game does not contain two rated players

# write parsed data into file
# format for each line: [game type]%[white elo rating]%[black elo rating]%[opening played]
print("Writing parsed data to output file...")
with open("parsed.txt", "w") as output_file:
    for i in range(len(parsed_data)):
        data_line = parsed_data[i][0]
        for j in range(1,4):
            data_line += f"%{parsed_data[i][j]}"
        output_file.write(f"{data_line}\n")
