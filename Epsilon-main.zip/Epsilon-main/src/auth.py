# SPDX-License-Identifier: AGPL-3.0-only

import hashlib
import getpass


def authenticate():
    with open("store/hash.txt", "r") as hash_file:
        password_hash = hash_file.read()

    while True:
        password_attempt = getpass.getpass(prompt="System Password:").encode()
        password_attempt = hashlib.sha256(password_attempt).hexdigest()
        if password_attempt == password_hash:
            print("Login success.\n")
            input("Press ENTER to continue:")
            print()
            break
        else:
            print("Incorrect password, please try again.")


def change_password():
    with open("store/hash.txt", "r") as hash_file:
        password_hash = hash_file.read()

    while True:
        password_attempt = getpass.getpass(prompt="System Password:").encode()
        password_attempt = hashlib.sha256(password_attempt).hexdigest()
        if password_attempt == password_hash:
            break
        else:
            print("Incorrect password, please try again.")

    while True:
        new_password = getpass.getpass(prompt="Please enter a new password:").encode()
        confirm_password = getpass.getpass(prompt="Confirm password:").encode()
        if new_password == confirm_password:
            with open("store/hash.txt", "w") as hash_file:
                new_password = hashlib.sha256(new_password).hexdigest()
                hash_file.write(new_password)
            print("Password changed successfully.")
            break
        else:
            print("Passwords do not match. Please try again.")
