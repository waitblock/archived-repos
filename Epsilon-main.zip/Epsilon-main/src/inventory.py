# SPDX-License-Identifier: AGPL-3.0-only

# inventory file formatting: [barcode] [name] [price] [quantity]

import time


def is_inventory_empty():
    with open("store/inventory.txt", "r") as inventory_file:
        if inventory_file.read() == "":
            return True
        return False


def read_items():
    if is_inventory_empty() is True:
        return []

    print("Reading item data...")
    with open("store/inventory.txt", "r") as inventory_file:
        raw_data = inventory_file.read().split("\n")

    items = []

    print("Parsing item data...")
    for i in range(len(raw_data)):
        item_data = raw_data[i].split(" ")
        item_barcode = int(item_data[0])
        item_name = item_data[1]
        item_price = float(item_data[2])
        item_quantity = int(item_data[3])
        items.append([item_barcode, item_name, item_price, item_quantity])

    return items


def does_item_exist(barcode):
    barcodes = []
    items = read_items()
    # print(items)
    for i in range(len(items)):
        barcodes.append(items[i][0])

    return barcode in barcodes


def write_items(items):
    with open("store/inventory.txt", "w") as inventory_file:
        for i in range(len(items)):
            line = items[i]
            write_data = f"{line[0]} {line[1]} {line[2]} {line[3]}"
            inventory_file.write(write_data)


def remove_item(barcode):
    items = read_items()
    temp = []

    for i in range(len(items)):
        if items[i][0] == barcode:
            # print("duplicate")
            continue
        temp.append(items[i])

    write_items(temp)


def get_details(barcode):
    items = read_items()
    try:
        barcode = int(barcode)
    except ValueError:
        return "The provided barcode is invalid. Please try again."
    if does_item_exist(barcode) is False:
        return "The provided barcode does not exist within the system. Please try again."
    out = ""
    print("Getting details...")
    for i in range(len(items)):
        if int(items[i][0]) == barcode:
            out += f"'{items[i][1]}' Details:\n"
            out += f"Inventory Count: {items[i][3]}\n"
            out += f"Price: {items[i][2]}\n"
            out += f"Barcode: {items[i][0]}\n"
            break
    return out


def get_inventory_levels():
    items = read_items()
    out = ""
    if is_inventory_empty() is True:
        return "There are no stored items in the system."
    for item in items:
        out += f"Barcode: {item[0]} | Item Name: {item[1]} | Item Price: {item[2]} | Item Stock: {item[3]}\n"
    return out


def add_item(barcode, name, price, quantity):
    try:
        barcode = int(barcode)
        price = float(price)
        quantity = int(quantity)
    except ValueError:
        print("Expected data types:\nbarcode: int\nname: string/str\nprice: float\nquantity: float")
        time.sleep(2)
        return

    print("Checking for duplicate item...")

    item_exists = does_item_exist(barcode)

    # print(item_exists)

    if item_exists is True:
        print("Item with identical barcode number already exists.")
        while True:
            overwrite = input("Do you wish to overwrite the item? [y/n]").lower()
            if overwrite == "yes" or overwrite == "y":
                print("Continuing...")
                break
            elif overwrite == "no" or overwrite == "n":
                print("Operation cancelled.")
                return
            else:
                print("Invalid option.")

    with open("store/inventory.txt", "a") as inventory_file:
        print("Adding item...")
        if item_exists is True:
            remove_item(barcode)
        if is_inventory_empty() is True:
            inventory_file.write(f"{barcode} {name} {price} {quantity}")
        else:
            inventory_file.write(f"\n{barcode} {name} {price} {quantity}")
