# SPDX-License-Identifier: AGPL-3.0-only

import sys
import startup
import menu
import auth


def main():
    try:
        startup.main()
        auth.authenticate()
        while True:
            menu.print_menu()
            menu.process_option(input(">"))
    except KeyboardInterrupt:
        print("\nShutting down...")
        sys.exit(0)


if __name__ == "__main__":
    main()
