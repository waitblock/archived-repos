# SPDX-License-Identifier: AGPL-3.0-only

import sys
import auth
import inventory
import os


def print_menu():
    try:
        print("\n" * os.get_terminal_size().lines)
        with open("store/menu.txt", "r") as menu_file:
            print(menu_file.read())
    except OSError:
        print("Please run the application from your terminal and try again. Running the application in IDLE will not work.")
        sys.exit(1)


def process_option(option):
    if option == "4":
        barcode = input("Enter the product barcode:")
        name = input("Enter the product name:")
        price = input("Enter the product price:")
        quantity = input("Enter the current inventory count for this product:")
        inventory.add_item(barcode, name, price, quantity)

    if option == "5":
        barcode = input("Enter the product barcode: ")
        print(inventory.get_details(barcode))
        input("Press ENTER to continue:")

    if option == "6":
        print(inventory.get_inventory_levels())
        input("Press ENTER to continue:")

    if option == "7":
        auth.change_password()

    if option == "8":
        print("Shutting down...")
        sys.exit(0)
