# SPDX-License-Identifier: AGPL-3.0-only

import sys
import subprocess
import os
from pathlib import Path


STARTUP_TEXT = "Epsilon v1.0.0\n\n(c) 2021 Ethan Xu\n\nThis program is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.\n\nThis program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.\n\nYou should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.\n"
MENU_TEXT = "\nMenu\n-----------------------------\n(1) Checkout\n(2) Set new price\n(3) Add new inventory\n(4) Add new item to system\n(5) View details for a specific item\n(6) View inventory levels\n(7) Change system password\n(8) Shutdown"
DEFAULT_HASH = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"


def path_check(pathname):
    from termcolor import cprint as colorprint
    print(f"Checking for {pathname}/...", end="")
    if os.path.exists(pathname):
        print("Done.")
    else:
        print("Done.")
        colorprint(f"{pathname}/ not found.", "yellow")
        print(f"Creating path {pathname}/...", end="")
        # print(os.getcwd())
        os.mkdir(os.path.join(os.getcwd(), pathname))
        print("Done.")


def create_inventoryfile(filename):
    from termcolor import cprint as colorprint
    print(f"Checking for {filename}...", end="")
    file_path = Path(filename)
    if file_path.is_file():
        print("Done.")
    else:
        print("Done.")
        colorprint(f"{filename} not found.", "yellow")
        print(f"Creating {filename}...", end="")
        file = open(filename, "w")
        file.close()
        print("Done.")


def create_startupfile(filename):
    from termcolor import cprint as colorprint
    print(f"Checking for {filename}...", end="")
    file_path = Path(filename)
    if file_path.is_file():
        print("Done.")
    else:
        print("Done.")
        colorprint(f"{filename} not found.", "yellow")
        print(f"Creating {filename}...", end="")
        file = open(filename, "w")
        file.write(STARTUP_TEXT)
        file.close()
        print("Done.")


def create_menufile(filename):
    from termcolor import cprint as colorprint
    print(f"Checking for {filename}...", end="")
    file_path = Path(filename)
    if file_path.is_file():
        print("Done.")
    else:
        print("Done.")
        colorprint(f"{filename} not found.", "yellow")
        print(f"Creating {filename}...", end="")
        file = open(filename, "w")
        file.write(MENU_TEXT)
        file.close()
        print("Done.")


def create_hashfile(filename):
    from termcolor import cprint as colorprint
    print(f"Checking for {filename}...", end="")
    file_path = Path(filename)
    if file_path.is_file():
        print("Done.")
    else:
        print("Done.")
        colorprint(f"{filename} not found.", "yellow")
        print(f"Creating {filename}...", end="")
        file = open(filename, "w")
        file.write(DEFAULT_HASH)
        file.close()
        print("Done.")


def main():
    install_pkgs = input("Install packages? [y/n]")

    if install_pkgs == "yes" or install_pkgs == "y":
        print("Installing packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

    from termcolor import cprint as colorprint
    print("Checking for UNIX kernel...", end="")
    if sys.platform != "darwin" and sys.platform != "linux" and sys.platform != "linux2":
        print("Done.")
        colorprint("This application is meant for systems built on the UNIX kernel. Using this application on a different type of system may cause issues.", "red")
    else:
        print("Done.")

    path_check("store")
    create_hashfile("store/hash.txt")
    create_inventoryfile("store/inventory.txt")
    create_menufile("store/menu.txt")
    create_startupfile("store/startup.txt")

    with open("store/startup.txt", "r") as startup:
        print(startup.read())
