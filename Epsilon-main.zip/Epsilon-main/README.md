![](https://img.shields.io/badge/license-AGPL--3.0-blue)
[![](https://ci.appveyor.com/api/projects/status/67jfqqbvwmnbwk17?svg=true)](https://ci.appveyor.com/project/waitblock/epsilon)
![](https://img.shields.io/badge/platform-macos%20%7C%20linux-lightgrey)
![](https://img.shields.io/github/last-commit/waitblock/Epsilon)
![](https://img.shields.io/tokei/lines/github/waitblock/Epsilon)
![](https://img.shields.io/github/repo-size/waitblock/Epsilon)

# Epsilon
An inventory management system with an integrated checkout system

## Installing
1. Install Python 3.5 or higher via [python.org](https://python.org) or via apt on Linux: `sudo apt-get install python`
2. Install pip (generally, this is bundled with the python installation) using [get-pip.py](https://bootstrap.pypa.io/get-pip.py) or via apt: `sudo apt-get install python3-pip`
3. Download this repository using the download button or via git: `git clone https://github.com/waitblock/Epsilon`
4. Run the application from the src folder using `python3 main.py`
5. When running the application for the first time, type 'yes' or 'y' when prompted to install packages (alternatively, you can just run `python3 -m pip install -r src/requirements.txt`)
6. The default system password is 'password'