import requests
from bs4 import BeautifulSoup
from countryinfo import CountryInfo
import matplotlib.pyplot as plt

metric = True

unit_system = input("By default, this program will run with the Metric system for its units. To change to the Customary system, hit 'c' then enter. If you would like to keep the Metric system, just hit enter. ")

if unit_system.lower() == 'c':
    metric = False

print("Compiling data...")
page = requests.get("https://www.worldometers.info/coronavirus")
if page.status_code == 200:
    soup = BeautifulSoup(page.content, 'lxml')
    table = soup.find('table', attrs={'id': 'main_table_countries_today'})
    rows = table.find_all("tr", attrs={"style": ""})
    raw_data = []
    for i,item in enumerate(rows):
        if i == 0:
            raw_data.append(item.text.strip().split("\n")[:13])
        else:
            raw_data.append(item.text.strip().split("\n")[:12])

    country_index = []
    formatted_data = []
    country_areas = []

    for i in range(2, len(raw_data)-200):
        country_index.append(raw_data[i][1])
        formatted_data.append(raw_data[i][2])

    remove_indexes = []
    to_remove = []

    for i in range(len(country_index)):
        country = CountryInfo(country_index[i])
        if metric == True:
            country_areas.append(country.area())
        elif metric == False:
            country_areas.append(country.area()/2.59)

    #remove commas for conversion to int
    for i in range(len(formatted_data)):
        formatted_data[i] = formatted_data[i].replace(',', '')

    #convert data to int
    for i in range(len(formatted_data)):
        formatted_data[i] = int(formatted_data[i])

    #summation of areas
    sum_area = 0
    for i in range(len(country_areas)):
        sum_area += country_areas[i]

    #summation of cases
    sum_cases = 0
    for i in range(len(country_areas)):
        sum_cases += formatted_data[i]

    #summation of the product of the cases and areas
    sum_product = 0
    for i in range(len(country_areas)):
        sum_product += (formatted_data[i] * country_areas[i])

    #summation of the squares of the areas
    square_areas_sum = 0
    for i in range(len(country_areas)):
        square_areas_sum += (country_areas[i]**2)

    #summation of the squares of the cases
    square_cases_sum = 0
    for i in range(len(formatted_data)):
        square_cases_sum += (formatted_data[i]**2)

    sample_size = len(country_areas)

    coef = ((sum_cases*square_areas_sum)-(sum_area*sum_product))/((sample_size*square_areas_sum)-(sum_area**2))
    intercept = ((sample_size*sum_product)-(sum_area*sum_cases))/((sample_size*square_areas_sum)-(sum_area**2))

    #print(len(country_areas))
    #print(len(formatted_data))
    #print(country_areas)
    #print(formatted_data)

    print(coef)
    print(intercept)

    fig, ax = plt.subplots()
    ax.scatter(country_areas, formatted_data)
    if metric == True:
        plt.xlabel("Area (km^2)")
    elif metric == False:
        plt.xlabel("Area (mi^2)")
    plt.ylabel("Total Cases")
    print("To exit the graph and use the predictor, close the window by clicking on X.")
    plt.show()

    print("Press Control-C or do a Keyboard Interruption to exit.")
    try:
        while True:
            if metric == True:
                in_area = input("Enter an area (km^2): ")
            elif metric == False:
                in_area = input("Enter an area (mi^2): ")

            prediction = coef * float(in_area) + intercept
            print("Estimated cases for given area ("+str(int(in_area))+"): "+str(prediction))
    except KeyboardInterrupt:
        exit()


else:
    print("An error occured. Status code", (page.status_code))
    exit()
