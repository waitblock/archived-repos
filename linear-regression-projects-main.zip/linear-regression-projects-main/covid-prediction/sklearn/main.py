import requests
from bs4 import BeautifulSoup
from countryinfo import CountryInfo
import matplotlib.pyplot as plt
import numpy as np
from sklearn import linear_model

metric = True

try:
    unit_system = input("By default, this program will run with the Metric system for its units. To change to the Customary system, hit 'c' then enter. If you would like to keep the Metric system, just hit enter. ")

    if unit_system.lower() == 'c':
        metric = False

    print("Compiling data...")
    page = requests.get("https://www.worldometers.info/coronavirus")
    if page.status_code == 200:
        soup = BeautifulSoup(page.content, 'lxml')
        table = soup.find('table', attrs={'id': 'main_table_countries_today'})
        rows = table.find_all("tr", attrs={"style": ""})
        raw_data = []
        for i,item in enumerate(rows):
            if i == 0:
                raw_data.append(item.text.strip().split("\n")[:13])
            else:
                raw_data.append(item.text.strip().split("\n")[:12])

        country_index = []
        formatted_data = []
        country_areas = []

        for i in range(2, len(raw_data)-200):
            country_index.append(raw_data[i][1])
            formatted_data.append(raw_data[i][2])

        remove_indexes = []
        to_remove = []

        for i in range(len(country_index)):
            country = CountryInfo(country_index[i])
            if metric == True:
                country_areas.append(country.area())
            elif metric == False:
                country_areas.append(country.area()/2.59)

        #remove commas for conversion to int
        for i in range(len(formatted_data)):
            formatted_data[i] = formatted_data[i].replace(',', '')

        #convert data to int
        for i in range(len(formatted_data)):
            formatted_data[i] = int(formatted_data[i])

        regression = linear_model.LinearRegression()
        _country_areas = np.array(country_areas).reshape(-1, 1)
        regression.fit(_country_areas,formatted_data)

        coef = regression.coef_
        intercept = regression.intercept_

        print(coef)
        print(intercept)

        fig, ax = plt.subplots()
        ax.scatter(country_areas, formatted_data)
        if metric == True:
            plt.xlabel("Area (km^2)")
        elif metric == False:
            plt.xlabel("Area (mi^2)")
        plt.ylabel("Total Cases")
        print("To exit the graph and use the predictor, close the window by clicking on X.")
        plt.show()

        print("Press Control-C or do a Keyboard Interruption to exit.")
        try:
            while True:
                if metric == True:
                    in_area = input("Enter an area (km^2): ")
                elif metric == False:
                    in_area = input("Enter an area (mi^2): ")

                prediction = coef * float(in_area) + intercept
                print("Estimated cases for given area ("+str(int(in_area))+"): "+str(prediction))
        except KeyboardInterrupt:
            exit()


    else:
        print("An error occurred. Status code", (page.status_code))
        exit()

except KeyboardInterrupt:
    exit()

except:
    print("An unknown error occurred.")
