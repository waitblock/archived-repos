pip3 install beautifulsoup4
pip3 install countryinfo
pip3 install numpy
pip3 install matplotlib
pip3 install requests
pip3 install scikit-learn
