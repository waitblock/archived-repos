import java.util.ArrayList;
import java.lang.Math;

public class Linear {

	public static void main(String[] args) {
		
	}
	
	static ArrayList<Double> linear(ArrayList<Double> x, ArrayList<Double> y){
		
		if(x.size() != y.size()) {
			System.out.println("ArraySameLengthException: Arrays must be of same length");
			return null;
		}
		
		//summation of x
		double sum_x = 0;
		for(int i = 0; i<x.size(); i++) {
			sum_x += x.get(i);
		}
		
		//summation of y
		double sum_y = 0;
		for(int i = 0; i<y.size(); i++) {
			sum_y += y.get(i);
		}
		
		//summation of products
		double sum_product = 0;
		for(int i = 0; i<x.size(); i++) {
			sum_product += (x.get(i) * y.get(i));
		}
		
		//summation of x squares
		double sum_x_square = 0;
		for(int i = 0; i<x.size(); i++) {
			sum_x_square += Math.pow(x.get(i), 2);
		}
		
		int sample_size_ = x.size();
		double sample_size = Double.valueOf(sample_size_);
		
		//calculate coefficient and intercept
		double coef = ((sample_size * sum_product)-(sum_x*sum_y))/((sample_size * sum_x_square)-Math.pow(sum_x, 2));
		double intercept = ((sum_y*sum_x_square)-(sum_x * sum_product))/((sample_size * sum_x_square)-Math.pow(sum_x, 2));
		
		//output array is in the format: {coefficient, intercept}
		ArrayList<Double> output = new ArrayList<Double>();
		output.add(coef);
		output.add(intercept);
		
		return output;
	}

}
