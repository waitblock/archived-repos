# BanBot

A bot that bans everyone in a server.

### Disclaimers:

- I am not liable for any damages caused by the use of this script, as said in the license file.
- Do NOT put a user token inside the 'TOKEN' string. That is against Discord's Terms of Service.
