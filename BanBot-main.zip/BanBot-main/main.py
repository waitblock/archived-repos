import discord

TOKEN = "" #bot token goes here
SKIP_BOTS = False #set true to skip banning bots


client = discord.Client()

@client.event
async def on_ready():
    print("Bot successfully logged in.")
    for member in client.get_all_members():
        if member.bot and SKIP_BOTS:
            continue
        await member.ban(reason="Automated ban by BanBot", delete_message_days=7)
        print(f"{member.display_name} has been banned.")
    print("Banning is complete.")

client.run(TOKEN)
