mount -uw /
rm /var/db/.applesetupdone
shutdown -h now
