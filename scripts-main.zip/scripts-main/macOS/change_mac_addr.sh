sudo ifconfig en0 ether aa:bb:cc:dd:ee:f2
