import sys
from salads.commandparser import interpret
from salads.startup import startup
from salads.startup import help_text


def main():
    startup()

    while True:
        command = input("salad # ")

        if command == 'exit' or command == 'quit':
            sys.exit(0)

        if command == 'help':
            print(help_text)

        else:
            interpret(command)


if __name__ == "__main__":
    main()
