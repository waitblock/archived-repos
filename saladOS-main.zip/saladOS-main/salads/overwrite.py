import os
import traceback


def run(filename):
    try:
        to_write = input("Enter text to overwrite to file -\n")
        confirm = input("Overwrite file - confirm? (y/n)").lower()
        if confirm == "yes" or confirm == "y":
            with open(os.path.join("documents", filename), "w") as file:
                file.write(to_write)
        elif confirm == "no" or confirm == "n":
            print("Operation cancelled")
        else:
            print("Unrecognized option, cancelling operation")
    except:
        print(traceback.print_exc())
