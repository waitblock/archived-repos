import os
import json


help_file_path = os.path.join("dressing", "help.txt")

with open(help_file_path, "r") as help_file:
    help_text = help_file.read()


def startup():
    version_file_path = os.path.join("dressing", "version.json")

    with open(version_file_path) as version_file:
        version_info = json.load(version_file)

    version = version_info["version"]

    print(f"saladOS {version} on {os.name}")
    print("(c) 2021 Ethan Xu")
    print("Use of the source files included is subject to the `LICENSE` file")
