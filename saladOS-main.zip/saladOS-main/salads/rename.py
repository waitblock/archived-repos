import os
import traceback


def run(args):
    try:
        original_name = os.path.join("documents", args.split(" ")[0])
        new_name = os.path.join("documents", args.split(" ")[1])
        os.rename(original_name, new_name)
    except:
        print(traceback.print_exc)
