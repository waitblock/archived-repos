import os
import traceback


def run(filename):
    try:
        path = os.path.join("documents", filename)
        file = open(path, "x")
        file.close()
    except:
        print(traceback.print_exc())
