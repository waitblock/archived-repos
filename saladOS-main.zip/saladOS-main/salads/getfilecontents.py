import os
import traceback


def run(fn):
    try:
        file_path = os.path.join("documents", fn)
        with open(file_path, "r") as file:
            return file.read()
    except:
        return traceback.print_exc()
