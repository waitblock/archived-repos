import os


def run():
    print(os.listdir(os.path.join(os.getcwd(), "documents")))
