# TODO: Implement befunge interpreter
