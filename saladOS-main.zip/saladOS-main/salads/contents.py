from salads.getfilecontents import run as get_contents


def run(filename):
    print(get_contents(filename))
