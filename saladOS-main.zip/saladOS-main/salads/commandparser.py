from salads import be
from salads import bf
from salads import contents
from salads import create
from salads import files
from salads import getfilecontents
from salads import remove
from salads import overwrite
from salads import rename


def interpret(command):
    if command[0:2] == "bf":
        bf.evaluate(getfilecontents.run(command[3:]))

    if command[0:8] == "contents":
        contents.run(command[9:])

    if command[0:6] == "create":
        create.run(command[7:])

    if command == "files":
        files.run()

    if command[0:6] == "remove":
        remove.run(command[7:])

    if command[0:6] == "rename":
        rename.run(command[7:])

    if command[0:9] == "overwrite":
        overwrite.run(command[10:])
