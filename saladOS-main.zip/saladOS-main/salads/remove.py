import os
import traceback


def run(filename):
    try:
        os.remove(os.path.join("documents", filename))
    except:
        print(traceback.print_exc())
