import os
import subprocess

# Reading files

with open('help.txt', 'r') as help_file:
    help_text = help_file.read()


def cd(args):  # unix: cd
    if args == "" or args == ".":
        print(os.getcwd())
    else:
        try:
            os.chdir(args)
        except FileNotFoundError:
            print("Directory does not exist")


def dir_():  # unix: ls
    directory_listing = os.listdir()
    for file in directory_listing:
        if file[0] != ".":
            print(file)


def getmac():  # unix: ifconfig
    print(subprocess.check_output(['ifconfig', 'en0', 'ether']).decode())


def help_():  # unix: help
    print(help_text)


def ipconfig(args):  # unix: ifconfig
    if args == "" or args == "/all":
        print(subprocess.check_output(['ifconfig']).decode())
    if args == "/flushdns":
        subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"])


def mkdir(args):  # unix: mkdir
    subprocess.call(['mkdir', args])


def rmdir(args):  # unix: rmdir/rm
    subprocess.call(['rm', '-r', args])


def ver():  # unix: uname
    os_uname = os.uname()
    print(os_uname[0] + " " + os_uname[2])
