# wclfm (Windows Command Line For MacOS) version 0.0.3 Build 1002
# (c) 2021 waitblock (Ethan) under the GNU GPL-3.0 License

try:
    from wclfm import *
    import os
    from termcolor import cprint

except ModuleNotFoundError:
    print("Missing required libraries.")
    print("Install the required libraries by running 'pip3 install -r requirements.txt'.")
    exit(1)

print("wclfm v0.0.3 (Build 1002)")

if os.uname()[0] != "Darwin":
    cprint("Warning: This program is intended for use only on MacOS (Darwin).", "red")


def main():
    os.chdir(os.getenv("HOME"))

    while True:
        command = input(os.getcwd() + ">")

        if command[0:2] == "cd":
            cd(command[3:])

        elif command == "dir":
            dir_()

        elif command == "exit":
            exit()

        elif command == "getmac":
            getmac()

        elif command == "help":
            help_()

        elif command[0:8] == "ipconfig":
            ipconfig(command[9:])

        elif command[0:5] == "mkdir":
            mkdir(command[6:])

        elif command[0:5] == "rmdir":
            rmdir(command[6:])

        elif command == "ver":
            ver()

        else:
            print("'" + command + "' is not recognized as an internal or external command, operable program or shell script.")


if __name__ == '__main__':
    main()
