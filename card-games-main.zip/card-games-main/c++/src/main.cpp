#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

const int ranks[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
const string suits[4] = {"♣", "♦", "♥", "♠"};
int playerTotal = 0;
int computerTotal = 0;
bool skipComputer = false;
char newHand = 'y';

int getRank();
string getSuit();

int main()
{
    cout << "CGTerm v0.1\n";
    while(newHand == 'y')
    {
        playerTotal += getRank();
        playerTotal += getRank();
        char option = 'h';
        while(option != 's')
        {
            std::cout << "Your total is: " << playerTotal << "\n";
            cout << "(H) Hit or (S) Stand: ";
            cin >> option;
            if(option == 'h')
            {
                int rank = getRank();
                playerTotal += rank;
                cout << "You drew: " << rank << getSuit() << "\n";
            }
            if(playerTotal > 21)
            {
                skipComputer = true;
                cout << "Player busted! Computer wins!" << "\n";
                break;
            }
            if(playerTotal == 21)
            {
                skipComputer = true;
                cout << "Player blackjack! Player wins!" << "\n";
                break;
            }
        }
        if(skipComputer == false)
        {
            while(computerTotal < 17)
            {
                computerTotal += getRank();
            }
            cout << "Player Total: " << playerTotal << "\n";
            cout << "Computer Total: " << computerTotal << "\n";
            if(computerTotal > 21)
            {
                cout << "The computer busted! Player wins!" << "\n";
            }
            if(computerTotal == 21)
            {
                cout << "Computer blackjack! Computer wins!" << "\n";
            }
            else{
                if(computerTotal > playerTotal)
                {
                    cout << "Computer is higher than player! Computer wins!" << "\n";
                }
                if(playerTotal > computerTotal)
                {
                    cout << "Player is higher than computer! Player wins!" << "\n";
                }
                if(playerTotal == computerTotal)
                {
                    cout << "Player is equal to computer! Tie!" << "\n";
                }
            }
        }
        playerTotal = 0;
        computerTotal = 0;
        cout << "Would you like to play another hand? (Y/N) ";
        cin >> newHand;
    }

    return 0;
}

int getRank()
{
    srand(time(NULL));
    int random = rand() % 10;
    return ranks[random];
}

string getSuit()
{
    srand(time(NULL));
    int random = rand() % 4;
    return suits[random];
}