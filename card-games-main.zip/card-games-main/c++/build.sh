g++ -std=c++17 src/main.cpp -o bin/blackjack
echo "Build completed."

./bin/blackjack